// src/components/PendingDeals.js
import React from 'react';
import '../styles/PendingDeals.css';

const PendingDeals = () => {
  const pendingDeals = [
    {  id: 1, name:"WORK", Type:"ProJect", Time: " 10:00-12-00PM" }, 
    { id: 2, name:"Food-Diet", Type:"Lunch", Time: "12:00 -1:00 AM" },
    { id: 3, name: "Sports", Type: "Badminton", Time: "4:00 - 6:00 AM" },
   
  ];

  return (
    <div className="pending-deals-container">
      <h2>Pending Tasks</h2>
      <div className="pending-deals-list">
        {pendingDeals.map((deal) => (
          <div className="pending-deal-card" key={deal.id}>
            <h3>{deal.name}</h3>
            <p>Status: {deal.Type}</p>
            <p>Value: {deal.Time}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PendingDeals;
