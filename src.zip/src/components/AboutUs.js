// src/components/AboutUs.js
import React from 'react';
import '../styles/AboutUs.css';
import { Code, Database, Zap, Shield, LifeBuoy } from 'lucide-react';

const AboutUs = () => {
  return (
    <div className="about-container">
      <h2>About Us</h2>

      <p>
          Welcome to the CUSTOMER RELATIONSHIP MANAGER Project! Our mission is to help individuals and fitness professionals manage their diet and workout plans more effectively, track progress, and enhance overall health and wellness. Our system provides a robust platform for managing fitness data, tracking meal plans and workouts, and monitoring fitness goals—making it an essential tool for anyone aiming to optimize their health management journey.
      </p>

      <p>
          Our CRM  is designed to streamline your fitness routine, improve nutrition tracking, and provide you with actionable insights for personal growth. From setting health goals to maintaining long-term fitness habits, our platform offers a range of features that help users stay consistent and motivated. Our focus is on delivering a user-friendly interface combined with powerful analytics to support informed, healthy decisions. 
      </p>

      <p>
         We believe in continuous improvement, which is why our team is always working on new features, performance optimizations, and user experience enhancements. Whether you're a personal trainer, a nutritionist, or an individual on a wellness journey, our CRM system can be customized to suit your specific needs. We're committed to providing reliable support and ensuring that every user gets the most out of our platform. 
      </p>

      <div className="team-section">
        <div className="team-member">
          <Code size={40} color="#3498db" />
          <h3>Frontend Development (UI/UX)</h3>
          <p><strong>Pradeep Chilukuri</strong></p>
          <p>Implement responsive layouts and navigation. Create forms for customer data entry, interaction logging, and sales tracking.</p>
        </div>

        <div className="team-member">
          <Database size={40} color="#e74c3c" />
          <h3>Backend Development (API & Database)</h3>
          <p><strong>D John Wesley</strong></p>
          <p>Manage the database (PostgreSQL, MySQL, or MongoDB) to store customer data, interactions, and sales pipeline details.</p>
        </div>

        <div className="team-member">
          <Zap size={40} color="#f39c12" />
          <h3>Automation & Integrations</h3>
          <p><strong>L Madhavan</strong></p>
          <p>Implement automation for email campaigns and follow-up reminders.</p>
        </div>

        <div className="team-member">
          <Shield size={40} color="#27ae60" />
          <h3>Security & Compliance</h3>
          <p><strong>Team Member Name</strong></p>
          <p>Ensure the security of customer data, manage user roles, and maintain compliance with data protection standards.</p>
        </div>

        <div className="team-member">
          <LifeBuoy size={40} color="#8e44ad" />
          <h3>User Support & Maintenance</h3>
          <p><strong>Team Member Name</strong></p>
          <p>Provide technical support, troubleshoot issues, and maintain system performance and availability.</p>
        </div>

      </div>
    </div>
  );
};

export default AboutUs;
