import React from 'react';
import '../styles/CompletedTasks.css';

const CompletedTasks = () => {
  const tasks = [
    { id: 1, title: 'Workout', time: '6:30 AM' },
    { id: 2, title: 'Breakfast', time: '8:00 AM' },
  ];

  return (
    <div className="completed-tasks-container">
      <h2>Completed Tasks</h2>
      <ul className="completed-tasks-list">
        {tasks.map((task) => (
          <li key={task.id} className="completed-task-item">
            <h3>{task.title}</h3>
            <p>{task.time}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CompletedTasks;
