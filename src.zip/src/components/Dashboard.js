// src/components/Dashboard.js
import React from 'react';
import { useNavigate } from 'react-router-dom';
import StatsCard from './StatsCard';
import NotificationsPanel from './NotificationsPanel';
import AnalyticsAndInsights from './AnalyticsAndInsights'; // ✅ Importing AnalyticsAndInsights
import '../styles/Dashboard.css';

const Dashboard = () => {
  const navigate = useNavigate();

  const stats = [
    { title: 'Number Of Customers', value: '150', icon: '🤵‍♂️', link: '/customers' },
    { title: ' Total Tasks ', value: '2', icon: '✍️', link: '/active-deals' },
    { title: 'Closed Tasks', value: '3', icon: '🚫', link: '/closed-deals' },
    { title: 'Pending Tasks', value: '2', icon: '🕒', link: '/pending-deals' },
    { title: 'Completed Tasks', value: '2', icon: '✔️', link: '/completed-tasks' },
    { title: 'Revenue Generated', value: '₹1,70,000', icon: '💰', link: '/revenue-generated' }
  ];

  return (
    <div className="dashboard">
      <h2 className="dashboard-title">Dashboard</h2>
      <div className="stats-grid">
        {stats.map((stat, index) => (
          <div key={index} onClick={() => stat.link && navigate(stat.link)}>
            <StatsCard title={stat.title} value={stat.value} icon={stat.icon} />
          </div>
        ))}
      </div>
      
      <NotificationsPanel />

      {/* ✅ Adding Analytics and Insights Component */}
      <AnalyticsAndInsights />
    </div>
  );
};

export default Dashboard;
